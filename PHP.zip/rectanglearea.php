<html>
The area of the rectangle is
<?php
	// get the value out
	$Height = (float)$_POST['Height'];
	$Width = (float)$_POST['Width']; 

	// do the calc
	$area = $Height * $Width;

	// put it into the html
	 ECHO ($area . "<br>");

	 if ($area > 10) {
		 echo "<br>" . $area . "is a big circle!";
	 } else {
		 echo "that was small";
	 }

?>
</html>
